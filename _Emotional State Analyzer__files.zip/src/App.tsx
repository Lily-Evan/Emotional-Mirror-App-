import  { useState, useRef, useCallback } from 'react';
import { Camera, Mic, Play, Pause, RotateCcw, Star, Music, Book, Heart } from 'lucide-react';

function App() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentEmotion, setCurrentEmotion] = useState<string>('');
  const [confidence, setConfidence] = useState<number>(0);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [hasPermissions, setHasPermissions] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const requestPermissions = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setHasPermissions(true);
    } catch (error) {
      console.error('Permission denied:', error);
    }
  }, []);

  const analyzeEmotion = useCallback(async () => {
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const emotions = ['Happy', 'Calm', 'Stressed', 'Focused', 'Tired', 'Anxious'];
      const emotion = emotions[Math.floor(Math.random() * emotions.length)];
      const conf = Math.floor(Math.random() * 30) + 70;
      
      setCurrentEmotion(emotion);
      setConfidence(conf);
      
      // Generate recommendations based on emotion
      const recs = generateRecommendations(emotion);
      setRecommendations(recs);
      setIsAnalyzing(false);
    }, 2000);
  }, []);

  const generateRecommendations = (emotion: string) => {
    const recMap: Record<string, any[]> = {
      'Stressed': [
        { type: 'music', title: 'Calm Piano', icon: Music },
        { type: 'meditation', title: '5-min Breathing', icon: Heart },
        { type: 'journal', title: 'Stress Journal', icon: Book }
      ],
      'Anxious': [
        { type: 'meditation', title: 'Anxiety Relief', icon: Heart },
        { type: 'music', title: 'Nature Sounds', icon: Music },
        { type: 'journal', title: 'Worry Log', icon: Book }
      ],
      'Tired': [
        { type: 'meditation', title: 'Energy Boost', icon: Heart },
        { type: 'music', title: 'Uplifting Beats', icon: Music }
      ],
      'Happy': [
        { type: 'journal', title: 'Gratitude Log', icon: Book },
        { type: 'music', title: 'Feel Good Playlist', icon: Music }
      ],
      'Calm': [
        { type: 'meditation', title: 'Mindfulness', icon: Heart },
        { type: 'journal', title: 'Reflection', icon: Book }
      ],
      'Focused': [
        { type: 'music', title: 'Focus Sounds', icon: Music },
        { type: 'journal', title: 'Achievement Log', icon: Book }
      ]
    };
    
    return recMap[emotion] || [];
  };

  const stopAnalysis = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setHasPermissions(false);
    setCurrentEmotion('');
    setConfidence(0);
    setRecommendations([]);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-indigo-100">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
                <Star className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Emotional Mirror
              </h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Understand Your Emotional Baseline
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            AI-powered analysis of your facial expressions and voice tone to provide personalized wellness insights and recommendations.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Camera Section */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">Live Analysis</h3>
            
            <div className="relative bg-gray-900 rounded-xl overflow-hidden mb-6" style={{aspectRatio: '4/3'}}>
              {hasPermissions ? (
                <video
                  ref={videoRef}
                  autoPlay
                  muted
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <Camera className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                    <p className="text-gray-400">Camera access required</p>
                  </div>
                </div>
              )}
              
              {isAnalyzing && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <div className="text-white text-center">
                    <div className="animate-spin w-8 h-8 border-2 border-white border-t-transparent rounded-full mx-auto mb-2"></div>
                    <p>Analyzing...</p>
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              {!hasPermissions ? (
                <button
                  onClick={requestPermissions}
                  className="flex-1 bg-indigo-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Camera className="w-5 h-5" />
                  Enable Camera & Mic
                </button>
              ) : (
                <>
                  <button
                    onClick={analyzeEmotion}
                    disabled={isAnalyzing}
                    className="flex-1 bg-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-green-700 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
                  >
                    <Play className="w-5 h-5" />
                    {isAnalyzing ? 'Analyzing...' : 'Start Analysis'}
                  </button>
                  <button
                    onClick={stopAnalysis}
                    className="px-6 py-3 border border-gray-300 rounded-xl font-semibold hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
                  >
                    <RotateCcw className="w-5 h-5" />
                    Reset
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">Emotional Insights</h3>
            
            {currentEmotion ? (
              <div className="space-y-6">
                {/* Current Emotion */}
                <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6">
                  <div className="text-center">
                    <h4 className="text-3xl font-bold text-indigo-600 mb-2">{currentEmotion}</h4>
                    <p className="text-gray-600">Confidence: {confidence}%</p>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
                      <div 
                        className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                        style={{width: `${confidence}%`}}
                      ></div>
                    </div>
                  </div>
                </div>

                {/* Recommendations */}
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Recommended For You</h4>
                  <div className="space-y-3">
                    {recommendations.map((rec, index) => (
                      <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors cursor-pointer">
                        <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                          <rec.icon className="w-5 h-5 text-indigo-600" />
                        </div>
                        <div>
                          <h5 className="font-semibold text-gray-900">{rec.title}</h5>
                          <p className="text-sm text-gray-600 capitalize">{rec.type}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <img 
                  src="https://images.unsplash.com/photo-1655970580622-4a547789c850?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxwZXJzb24lMjBtZWRpdGF0aW5nJTIwZW1vdGlvbmFsJTIwd2VsbG5lc3MlMjBtaW5kZnVsbmVzc3xlbnwwfHx8fDE3NTExMjUzNTF8MA&ixlib=rb-4.1.0"
                  alt="Person meditating with headphones"
                  className="w-32 h-32 object-cover rounded-full mx-auto mb-4"
                />
                <p className="text-gray-600">Start analysis to see your emotional insights</p>
              </div>
            )}
          </div>
        </div>

        {/* Features */}
        <div className="mt-16 grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <img 
              src="https://images.unsplash.com/photo-1690150268757-516babbdfc3d?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxwZXJzb24lMjBtZWRpdGF0aW5nJTIwZW1vdGlvbmFsJTIwd2VsbG5lc3MlMjBtaW5kZnVsbmVzc3xlbnwwfHx8fDE3NTExMjUzNTF8MA&ixlib=rb-4.1.0"
              alt="Person doing yoga by water"
              className="w-24 h-24 object-cover rounded-full mx-auto mb-4"
            />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Real-time Analysis</h3>
            <p className="text-gray-600">AI analyzes facial expressions and voice patterns in real-time</p>
          </div>
          
          <div className="text-center">
            <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-12 h-12 text-indigo-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Personalized Care</h3>
            <p className="text-gray-600">Get tailored recommendations for music, meditation, and journaling</p>
          </div>
          
          <div className="text-center">
            <img 
              src="https://images.unsplash.com/photo-1629049224884-af8734824449?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxwZXJzb24lMjBtZWRpdGF0aW5nJTIwZW1vdGlvbmFsJTIwd2VsbG5lc3MlMjBtaW5kZnVsbmVzc3xlbnwwfHx8fDE3NTExMjUzNTF8MA&ixlib=rb-4.1.0"
              alt="Person meditating outdoors"
              className="w-24 h-24 object-cover rounded-full mx-auto mb-4"
            />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Wellness Tracking</h3>
            <p className="text-gray-600">Monitor emotional patterns and improve mental well-being</p>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
 